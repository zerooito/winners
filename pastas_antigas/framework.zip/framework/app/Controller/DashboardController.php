<?php

class DashboardController extends AppController{

	function home() {
		$this->layout = 'wadmin';
	}

}