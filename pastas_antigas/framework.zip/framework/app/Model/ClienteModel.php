<?php

class Cliente extends AppModel{

}