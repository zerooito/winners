<?php

class FuncionarioController extends AppController {
	public $matricula;
	public $salario;
	public $departamento;

	function incluir() {
		return true;
	}

	function excluir() {
		return true;
	}

	function editar() {
		return true;
	}

}