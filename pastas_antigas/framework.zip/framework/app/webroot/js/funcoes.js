$(document).ready(function(){
	$('#enviar').click(function(){
		$('#cadastrar').submit();
	});
});