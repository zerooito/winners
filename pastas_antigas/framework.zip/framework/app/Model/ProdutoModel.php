<?php

class Produto extends AppModel{
	
}