<?php
App::uses('AppModel', 'Model');

class TesteModel extends AppModel{
	public $teste = 'TesteModel';
}