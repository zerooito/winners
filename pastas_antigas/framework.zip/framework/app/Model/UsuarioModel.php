<?php

class Usuario extends AppModel{
	public $usuario = 'UsuarioModel';

	function teste(){
		echo 'teste';
	}
}